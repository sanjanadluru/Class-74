import numpy as np
import os
import cv2

# Create path variable and store the path of the dataset folder

# Create two lists infected and uninfected to store the infected and uninfected images


# Write a for loop to go through each image path in the path variable's location

    # Add a try block
    
        #Print path of the image
        
    
        # Use split method to split the image name from "_" character to get the first character representing type of image and save it in type variable
        
        # Read the image
        
        # Covert the image from BGR to RGB
        
        # Check if type == 0  and append the image in the infected list else append in the uninfected list
        
        
    
    # Add an except block          
    


# Print length of infected image list


# Print length of infected image list
